---
name: Feature Implementation
about: Template for AI-assisted feature implementation
---

## Objective
[Clear objective statement]

## Requirements
- [ ] Requirement 1
- [ ] Requirement 2

## Implementation Plan
1. Step 1
2. Step 2

## Acceptance Criteria
- [ ] Criteria 1
- [ ] Criteria 2
